#!/bin/bash
set -e # Detiene el script si ocurre algún error

export AWS_DEFAULT_REGION=us-east-1
KEY_NAME="vockey" # Nombre habitual de la clave en AWS Academy (usa labsuser.pem)

echo "1. Obteniendo tu IP pública actual..."
MY_IP="213.0.86.0/23"
echo "1. Usando rango IP autorizado para SSH: $MY_IP"

echo "2. Creando VPC 'vpc-reto' (10.30.0.0/16)..."
VPC=$(aws ec2 create-vpc --cidr-block 10.30.0.0/16 \
  --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=vpc-reto}]' \
  --query Vpc.VpcId --output text)
aws ec2 modify-vpc-attribute --vpc-id $VPC --enable-dns-hostnames
echo "   -> VPC ID: $VPC"

echo "3. Creando subred pública (10.30.1.0/24)..."
SN=$(aws ec2 create-subnet --vpc-id $VPC --cidr-block 10.30.1.0/24 \
  --availability-zone us-east-1a \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=sn-publica-reto}]' \
  --query Subnet.SubnetId --output text)
aws ec2 modify-subnet-attribute --subnet-id $SN --map-public-ip-on-launch
echo "   -> Subnet ID: $SN"

echo "4. Creando y adjuntando Internet Gateway..."
IGW=$(aws ec2 create-internet-gateway \
  --tag-specifications 'ResourceType=internet-gateway,Tags=[{Key=Name,Value=igw-reto}]' \
  --query InternetGateway.InternetGatewayId --output text)
aws ec2 attach-internet-gateway --internet-gateway-id $IGW --vpc-id $VPC
echo "   -> IGW ID: $IGW"

echo "5. Configurando Tabla de Rutas..."
RT=$(aws ec2 create-route-table --vpc-id $VPC \
  --tag-specifications 'ResourceType=route-table,Tags=[{Key=Name,Value=rt-publica-reto}]' \
  --query RouteTable.RouteTableId --output text)
aws ec2 create-route --route-table-id $RT --destination-cidr-block 0.0.0.0/0 --gateway-id $IGW > /dev/null
aws ec2 associate-route-table --route-table-id $RT --subnet-id $SN > /dev/null
echo "   -> Route Table ID: $RT"

echo "6. Creando Security Group 'sgr-reto'..."
SG=$(aws ec2 create-security-group --group-name sgr-reto \
  --description "Permite HTTP global y SSH desde mi IP" \
  --vpc-id $VPC --query GroupId --output text)

# Regla HTTP (puerto 80) para todo el mundo
aws ec2 authorize-security-group-ingress --group-id $SG \
  --protocol tcp --port 80 --cidr 0.0.0.0/0 > /dev/null

# Regla SSH (puerto 22) solo desde tu IP
aws ec2 authorize-security-group-ingress --group-id $SG \
  --protocol tcp --port 22 --cidr $MY_IP > /dev/null
echo "   -> Security Group ID: $SG"

echo "7. Preparando User Data y buscando última AMI de Amazon Linux 2023..."
cat << 'EOF' > userdata.sh
#!/bin/bash
dnf update -y
dnf install -y httpd
systemctl start httpd
systemctl enable httpd
echo "<h1>Servidor Web en VPC Reto - Host: $(hostname -f)</h1>" > /var/www/html/index.html
EOF

AMI_ID=$(aws ssm get-parameters \
  --names /aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64 \
  --query 'Parameters[0].Value' --output text)

echo "8. Lanzando instancia EC2 'ec2-reto'..."
INSTANCE_ID=$(aws ec2 run-instances \
  --image-id $AMI_ID \
  --instance-type t3.micro \
  --key-name $KEY_NAME \
  --subnet-id $SN \
  --security-group-ids $SG \
  --user-data file://userdata.sh \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=ec2-reto}]' \
  --query 'Instances[0].InstanceId' --output text)

# Limpiamos el archivo temporal de userdata
rm -f userdata.sh

echo "   -> Esperando a que la instancia esté en estado 'running'..."
aws ec2 wait instance-running --instance-ids $INSTANCE_ID

PUBLIC_IP=$(aws ec2 describe-instances --instance-ids $INSTANCE_ID \
  --query 'Reservations[0].Instances[0].PublicIpAddress' --output text)

echo "=========================================="
echo "¡Despliegue completado con éxito!"
echo "ID Instancia: $INSTANCE_ID"
echo "IP Pública:   $PUBLIC_IP"
echo "Prueba en 30 segundos con: curl http://$PUBLIC_IP"
echo "=========================================="
